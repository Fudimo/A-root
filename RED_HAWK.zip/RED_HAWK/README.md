# RED HAWK
#### Version 1.1.0
#### By R3D#@0R_2H1N A.K.A Tuhinshubhra
RED HAWK is An All In One Tool For Information Gathering, SQL Vulnerability Scannig and Crawling.Coded In PHP

![Alt text](http://oi67.tinypic.com/5founq.jpg "Screenshot")

# Features Of The Tool:
+ Server detection
+ Cloudflare detector
+ robots scanner
+ CMS Detector
    + WordPress
    + Joomla
    + Drupal
    + Magento
+ Whois
+ GEO-IP Scan
+ NMAP Port Scan
+ DNS Lookup
+ SubNet Calculator
+ Subdomain Finder
+ Reverse IP Scanner
    + CMS detection For Sites On the same server.
+ Parameter Finder
    + Error based SQLi Detector
+ Crawler
  + Basic Crawler {69}
   - [ - ] Admin scanner
   - [ - ] Backups Finder
   - [ - ] Misc. Crawler
  + Advance Crawler{420}
   - [ - ] Admin scanner
   - [ - ] Backups Finder
   - [ - ] Misc. Crawler
---
# Released Versions:
    - Version 1.0.0 [11-06-2017]
    - Version 1.1.0 [15-06-2017]

# Changelog:
- Version 1.0.0
    - Initial Launch
- Version 1.1.0
    - Updated The `fix` command

# Installation:
Run The Tool and Type `fix` This will Install All Required Modules.

# Usage:
- git clone `https://github.com/Tuhinshubhra/RED_HAWK`
- cd RED_HAWK
- php rhawk.php
- Use the "help" command to see the command list or type in the domain name you want to scan (without Http:// OR Https://).
- Select whether The Site Runs On HTTPS or not.
- Leave The Rest To The Scanner

# Known Issues
**ISSUE:** Scanner Stops Working After Cloudflare Detection!

**SOLUTION:** Use The `fix` Command OR Manually Install *php-curl* & *php-xml*

Watch The Video TO See How To Solve This Isuue : https://www.youtube.com/watch?v=QuFPY9NFTM8

# Video Demonstration
<a href="http://www.youtube.com/watch?feature=player_embedded&v=pH9fn3DExDk" target="_blank"><img src="http://oi68.tinypic.com/9l8xzo.jpg" 
alt="IMAGE ALT TEXT HERE" border="10" /></a>
