###TODO:

* Add web port scans for directed web scans
* Add various modes (airstrike,nuke,web,etc.) for discovery scans
* Add automatic reporting for all scans by default
* Add Metasploit RCE exploit for MS17-010 (ETTERNALBLUE)
* Add Metasploit RCE exploit for CVE-2016-6366 (EXTRABACON)
* Add reporting for discover mode
