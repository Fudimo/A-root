#!/bin/bash
# build script to push to github... 
git add *
git commit -m 'Sn1per by 1N3CrowdShield'
git push origin master
